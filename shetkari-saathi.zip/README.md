# Shetkari Saathi 🌾

Shetkari Saathi (शेतकरी साथी - "Farmer's Companion") is a mini-project built for
final year Computer Engineering coursework. A lot of farmers and rural
entrepreneurs in Maharashtra don't get to know about government schemes they
are eligible for, or the free digital tools that could make their work easier,
mostly because the information is scattered across many websites/PDFs and
usually only in English.

This site puts the important schemes and tools in one place, in English,
Marathi and Hindi.

## What it does

- Lists 8 major government schemes for farmers/rural entrepreneurs with
  eligibility, benefit and how-to-apply info, and a direct link to the
  official page.
- Lists 8 free digital tools (Kisan Suvidha, AgMarknet, e-NAM, UPI, DigiLocker,
  UMANG, etc.)
- Works in 3 languages - switch using the buttons in the header (saved in
  the browser so it remembers your choice next time).
- Search + filter on the schemes page.
- Contact form (stores messages in the browser's localStorage for now, no
  backend/server yet).

## Tech stack

Plain HTML, CSS and JavaScript. No frameworks, no build step - just open
`index.html` in a browser, or serve the folder with any static file server.

## Project structure

```
index.html      -> homepage
schemes.html    -> all government schemes, with search/filter
tools.html      -> digital tools grid
about.html      -> about the project + team
contact.html    -> contact form
404.html        -> not found page
css/
  style.css     -> all styling
js/
  data.js       -> scheme + tool data (all 3 languages)
  i18n.js       -> translation strings + language switching
  main.js       -> renders scheme/tool cards, search/filter, contact form
assets/
  favicon.ico
```

## Running it locally

No installation needed. Just open `index.html` in a browser.

If you want to serve it properly (recommended, so relative links behave the
way they would on a real host), from this folder run:

```bash
python3 -m http.server 8000
```

and open http://localhost:8000

## Notes / things left to do

- [ ] Hook up the contact form to an actual email service / Google Form
- [ ] Add more schemes (state-specific ones especially)
- [ ] Add real team member names/photos in About page
- [ ] Maybe add a "schemes near me" filter by district

## Team

- Team Member 1 - Computer Engineering
- Team Member 2 - Computer Engineering
- Team Member 3 - Computer Engineering

## Disclaimer

Scheme details are collected from official government portals for reference.
Please double check on the official website before applying, since rules and
amounts do change.
