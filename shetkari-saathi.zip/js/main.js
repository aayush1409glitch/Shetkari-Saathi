// Page-specific rendering. Depends on data.js and i18n.js being loaded first.

function schemeCardHtml(s, lang, full) {
  if (full) {
    return `
      <article class="card card-thick-border" id="${s.id}">
        <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:8px;">
          <h2 class="card-title">${s.name[lang]}</h2>
          <span class="tag-pill" style="flex-shrink:0;">${s.tag[lang]}</span>
        </div>
        <p>${s.summary[lang]}</p>
        <dl>
          <dt>${t("eligibility")}:</dt>
          <dd>${s.eligibility[lang]}</dd>
          <dt>${t("benefit")}:</dt>
          <dd>${s.benefit[lang]}</dd>
          <dt>${t("howToApply")}:</dt>
          <dd>${s.apply[lang]}</dd>
        </dl>
        <a class="btn btn-primary" href="${s.link}" target="_blank" rel="noopener noreferrer">${t("officialLink")} ↗</a>
      </article>
    `;
  }
  return `
    <div class="card">
      <span class="tag-pill">${s.tag[lang]}</span>
      <h3>${s.name[lang]}</h3>
      <p>${s.summary[lang]}</p>
      <a class="link-arrow" href="schemes.html#${s.id}">${t("viewAll")} →</a>
    </div>
  `;
}

function toolCardHtml(tool, lang) {
  return `
    <div class="card card-thick-border">
      <span class="tag-pill square">${tool.category[lang]}</span>
      <h2 class="card-title">${tool.name}</h2>
      <p>${tool.description[lang]}</p>
      <a class="btn btn-primary" href="${tool.link}" target="_blank" rel="noopener noreferrer">${t("visitSite")} ↗</a>
    </div>
  `;
}

function renderFeaturedSchemes() {
  const container = document.getElementById("featured-schemes");
  if (!container) return;
  const lang = getLang();
  container.innerHTML = SCHEMES.slice(0, 3).map((s) => schemeCardHtml(s, lang, false)).join("");
}

function renderToolsGrid() {
  const container = document.getElementById("tools-grid");
  if (!container) return;
  const lang = getLang();
  container.innerHTML = TOOLS.map((tool) => toolCardHtml(tool, lang)).join("");
}

// ----- Schemes page: search + tag filter -----

let schemesFilterTag = "all";
let schemesSearchQuery = "";

function renderSchemesList() {
  const container = document.getElementById("schemes-list");
  if (!container) return;
  const lang = getLang();

  const q = schemesSearchQuery.trim().toLowerCase();
  const filtered = SCHEMES.filter((s) => {
    const inTag = schemesFilterTag === "all" || s.tag.en === schemesFilterTag;
    const inQuery =
      !q ||
      s.name[lang].toLowerCase().includes(q) ||
      s.summary[lang].toLowerCase().includes(q) ||
      s.name.en.toLowerCase().includes(q);
    return inTag && inQuery;
  });

  if (filtered.length === 0) {
    container.innerHTML = `<p style="font-size:14px; color:#3a5a40;">${t("noResults")}</p>`;
    return;
  }

  container.innerHTML = filtered.map((s) => schemeCardHtml(s, lang, true)).join("");
}

function renderSchemeFilterButtons() {
  const container = document.getElementById("scheme-tag-filters");
  if (!container) return;
  const tags = ["all", ...Array.from(new Set(SCHEMES.map((s) => s.tag.en)))];
  container.innerHTML = tags
    .map((tag) => {
      const label = tag === "all" ? t("all") : tag;
      const active = tag === schemesFilterTag ? "active" : "";
      return `<button type="button" class="filter-btn ${active}" data-tag="${tag}">${label}</button>`;
    })
    .join("");

  container.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      schemesFilterTag = btn.getAttribute("data-tag");
      renderSchemeFilterButtons();
      renderSchemesList();
    });
  });
}

function initSchemesSearch() {
  const input = document.getElementById("scheme-search");
  if (!input) return;
  input.addEventListener("input", (e) => {
    schemesSearchQuery = e.target.value;
    renderSchemesList();
  });
}

// ----- Contact form -----

function initContactForm() {
  const form = document.getElementById("contact-form");
  if (!form) return;
  const successMsg = document.getElementById("contact-success");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = {
      name: form.elements["name"].value,
      email: form.elements["email"].value,
      message: form.elements["message"].value,
      at: new Date().toISOString(),
    };
    try {
      const key = "ss_messages";
      const existing = JSON.parse(window.localStorage.getItem(key) || "[]");
      existing.push(data);
      window.localStorage.setItem(key, JSON.stringify(existing));
    } catch (err) {
      console.warn("Could not save message locally:", err);
    }
    form.reset();
    if (successMsg) successMsg.classList.add("show");
  });
}

// Re-render everything that depends on the current language.
window.onLangChange = function () {
  renderFeaturedSchemes();
  renderToolsGrid();
  renderSchemeFilterButtons();
  renderSchemesList();
};

document.addEventListener("DOMContentLoaded", () => {
  initSchemesSearch();
  initContactForm();
});
