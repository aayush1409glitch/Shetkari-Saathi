// Simple translation dictionary + language switcher.
// Every page includes this file. Elements tagged data-i18n="key" get their
// text swapped when the language changes. Elements tagged
// data-i18n-placeholder="key" get their placeholder attribute swapped.

const TRANSLATIONS = {
  siteName: { en: "Shetkari Saathi", mr: "शेतकरी साथी", hi: "किसान साथी" },
  tagline: {
    en: "Bridging farmers with schemes and digital tools",
    mr: "शेतकऱ्यांना योजना आणि डिजिटल साधनांशी जोडणारा पूल",
    hi: "किसानों को योजनाओं और डिजिटल साधनों से जोड़ने वाला सेतु",
  },
  navHome: { en: "Home", mr: "मुख्यपृष्ठ", hi: "मुख्य पृष्ठ" },
  navSchemes: { en: "Schemes", mr: "योजना", hi: "योजनाएँ" },
  navTools: { en: "Digital Tools", mr: "डिजिटल साधने", hi: "डिजिटल साधन" },
  navAbout: { en: "About", mr: "आमच्याबद्दल", hi: "हमारे बारे में" },
  navContact: { en: "Contact", mr: "संपर्क", hi: "संपर्क" },

  heroHeading: {
    en: "Government schemes & digital tools for rural Maharashtra",
    mr: "ग्रामीण महाराष्ट्रासाठी शासकीय योजना आणि डिजिटल साधने",
    hi: "ग्रामीण महाराष्ट्र के लिए सरकारी योजनाएँ और डिजिटल साधन",
  },
  heroText: {
    en: "A simple, trilingual guide made for rural entrepreneurs and farmers. Learn about schemes you are eligible for and the free tools that can grow your work.",
    mr: "ग्रामीण उद्योजक आणि शेतकऱ्यांसाठी बनवलेले सोपे, त्रिभाषिक मार्गदर्शक. तुम्हाला मिळू शकणाऱ्या योजना आणि तुमचा व्यवसाय वाढवणारी मोफत साधने जाणून घ्या.",
    hi: "ग्रामीण उद्यमियों और किसानों के लिए बनाया गया सरल, त्रिभाषी मार्गदर्शक। जानें कि आप किन योजनाओं के पात्र हैं और कौन-कौन से मुफ्त डिजिटल साधन आपके काम को बढ़ा सकते हैं।",
  },
  ctaSchemes: { en: "Browse Schemes", mr: "योजना पहा", hi: "योजनाएँ देखें" },
  ctaTools: { en: "See Digital Tools", mr: "डिजिटल साधने पहा", hi: "डिजिटल साधन देखें" },

  heroQuote: {
    en: '"One language, one farmer, one click"',
    mr: '"एक भाषा, एक शेतकरी, एक क्लिक"',
    hi: '"एक भाषा, एक किसान, एक क्लिक"',
  },
  heroPoint1: { en: "8+ Government Schemes", mr: "८+ शासकीय योजना", hi: "8+ सरकारी योजनाएँ" },
  heroPoint2: { en: "8+ Free Digital Tools", mr: "८+ मोफत डिजिटल साधने", hi: "8+ मुफ्त डिजिटल साधन" },
  heroPoint3: { en: "Available in 3 languages", mr: "३ भाषांमध्ये उपलब्ध", hi: "3 भाषाओं में उपलब्ध" },
  heroPoint4: { en: "Direct official links", mr: "थेट अधिकृत दुवे", hi: "सीधे आधिकारिक लिंक" },

  problemHeading: {
    en: "The problem we are solving",
    mr: "आम्ही सोडवत असलेली समस्या",
    hi: "हम जो समस्या हल कर रहे हैं",
  },
  problemText: {
    en: "Rural entrepreneurs in Maharashtra face a big information gap about government schemes and digital tools. Most information is in English, buried in PDFs, or spread across many websites. We collect it in one place, in your language.",
    mr: "महाराष्ट्रातील ग्रामीण उद्योजकांना शासकीय योजना आणि डिजिटल साधनांबाबत मोठी माहितीची तूट भासते. बहुतेक माहिती इंग्रजीत, पीडीएफ मध्ये किंवा अनेक वेबसाइट्सवर विखुरलेली असते. आम्ही ती एका ठिकाणी, तुमच्या भाषेत आणतो.",
    hi: "महाराष्ट्र के ग्रामीण उद्यमियों को सरकारी योजनाओं और डिजिटल साधनों की जानकारी की बड़ी कमी है। अधिकांश जानकारी अंग्रेज़ी में, पीडीएफ में या कई वेबसाइटों पर बिखरी होती है। हम इसे एक जगह, आपकी भाषा में लाते हैं।",
  },

  featuredSchemes: { en: "Featured schemes", mr: "निवडक योजना", hi: "प्रमुख योजनाएँ" },
  viewAll: { en: "View all", mr: "सर्व पहा", hi: "सभी देखें" },
  eligibility: { en: "Eligibility", mr: "पात्रता", hi: "पात्रता" },
  benefit: { en: "Benefit", mr: "लाभ", hi: "लाभ" },
  howToApply: { en: "How to apply", mr: "अर्ज कसा करावा", hi: "आवेदन कैसे करें" },
  officialLink: { en: "Official link", mr: "अधिकृत दुवा", hi: "आधिकारिक लिंक" },
  searchPlaceholder: { en: "Search...", mr: "शोधा...", hi: "खोजें..." },
  noResults: {
    en: "No schemes match your search.",
    mr: "तुमच्या शोधाशी जुळणारी कोणतीही योजना नाही.",
    hi: "आपकी खोज से कोई योजना मेल नहीं खाती।",
  },
  all: { en: "All", mr: "सर्व", hi: "सभी" },

  schemesHeading: { en: "Government Schemes", mr: "शासकीय योजना", hi: "सरकारी योजनाएँ" },
  toolsHeading: {
    en: "Free digital tools for your work",
    mr: "तुमच्या कामासाठी मोफत डिजिटल साधने",
    hi: "आपके काम के लिए मुफ्त डिजिटल साधन",
  },
  visitSite: { en: "Visit site", mr: "साइटला भेट द्या", hi: "साइट पर जाएँ" },

  aboutHeading: { en: "About this project", mr: "या प्रकल्पाबद्दल", hi: "इस परियोजना के बारे में" },
  aboutText: {
    en: "This website was built as a final year engineering project to help rural entrepreneurs and farmers in Maharashtra get correct information about government schemes and free digital tools. It works in English, Marathi and Hindi. Content is compiled from official government portals.",
    mr: "हे संकेतस्थळ अंतिम वर्ष अभियांत्रिकी प्रकल्प म्हणून बनवले आहे, जेणेकरून महाराष्ट्रातील ग्रामीण उद्योजक आणि शेतकऱ्यांना शासकीय योजना आणि मोफत डिजिटल साधनांची योग्य माहिती मिळेल. हे इंग्रजी, मराठी आणि हिंदी भाषेत काम करते. मजकूर अधिकृत शासकीय पोर्टलवरून घेतला आहे.",
    hi: "यह वेबसाइट अंतिम वर्ष के इंजीनियरिंग प्रोजेक्ट के रूप में बनाई गई है ताकि महाराष्ट्र के ग्रामीण उद्यमियों और किसानों को सरकारी योजनाओं और मुफ्त डिजिटल साधनों की सही जानकारी मिल सके। यह अंग्रेज़ी, मराठी और हिंदी में काम करती है। सामग्री आधिकारिक सरकारी पोर्टलों से ली गई है।",
  },
  objectivesHeading: { en: "Objectives", mr: "उद्दिष्टे", hi: "उद्देश्य" },
  objective1: {
    en: "Collect information on 8+ major government schemes for farmers and rural entrepreneurs.",
    mr: "शेतकरी व ग्रामीण उद्योजकांसाठी ८+ प्रमुख शासकीय योजनांची माहिती एकत्रित करणे.",
    hi: "किसानों और ग्रामीण उद्यमियों के लिए 8+ प्रमुख सरकारी योजनाओं की जानकारी एकत्र करना।",
  },
  objective2: {
    en: "Present it in English, Marathi and Hindi so language is not a barrier.",
    mr: "इंग्रजी, मराठी व हिंदीत ती सादर करणे, जेणेकरून भाषा अडथळा ठरू नये.",
    hi: "इसे अंग्रेज़ी, मराठी और हिंदी में प्रस्तुत करना ताकि भाषा बाधा न बने।",
  },
  objective3: {
    en: "List free digital tools that solve real day-to-day problems.",
    mr: "दैनंदिन समस्या सोडवणाऱ्या मोफत डिजिटल साधनांची यादी.",
    hi: "रोज़मर्रा की समस्याओं को हल करने वाले मुफ्त डिजिटल साधनों की सूची।",
  },
  objective4: {
    en: "Link directly to official portals - never ask users for personal data.",
    mr: "अधिकृत पोर्टलचे थेट दुवे - कधीही वैयक्तिक माहिती मागत नाही.",
    hi: "आधिकारिक पोर्टलों के सीधे लिंक - कभी भी व्यक्तिगत डेटा नहीं माँगते।",
  },
  techHeading: { en: "Tech stack", mr: "तंत्रज्ञान", hi: "तकनीक" },
  team: { en: "Team", mr: "टीम", hi: "टीम" },

  contactHeading: { en: "Get in touch", mr: "संपर्कात रहा", hi: "संपर्क करें" },
  contactText: {
    en: "Have a scheme we should add, or feedback in your local language? Send us a message.",
    mr: "आम्ही जोडावी अशी एखादी योजना आहे, किंवा तुमच्या स्थानिक भाषेत काही सूचना? आम्हाला संदेश पाठवा.",
    hi: "कोई योजना जो हमें जोड़नी चाहिए, या अपनी स्थानीय भाषा में सुझाव है? हमें संदेश भेजें।",
  },
  name: { en: "Name", mr: "नाव", hi: "नाम" },
  email: { en: "Email", mr: "ईमेल", hi: "ईमेल" },
  message: { en: "Message", mr: "संदेश", hi: "संदेश" },
  send: { en: "Send", mr: "पाठवा", hi: "भेजें" },
  sent: {
    en: "Thanks! Your message has been recorded.",
    mr: "धन्यवाद! तुमचा संदेश नोंदवला आहे.",
    hi: "धन्यवाद! आपका संदेश दर्ज कर लिया गया है।",
  },
  directContact: { en: "Direct contact", mr: "थेट संपर्क", hi: "सीधा संपर्क" },

  footerNote: {
    en: "A college mini-project · Info collected from official government portals, please verify before applying",
    mr: "हा एक कॉलेज मिनी-प्रोजेक्ट आहे · माहिती अधिकृत शासकीय पोर्टलवरून घेतली आहे, अर्ज करण्यापूर्वी खात्री करा",
    hi: "यह एक कॉलेज मिनी-प्रोजेक्ट है · जानकारी सरकारी पोर्टलों से ली गई है, आवेदन से पहले पुष्टि कर लें",
  },
  footerCopy: {
    en: "© 2025 Shetkari Saathi · Built as a college mini-project",
    mr: "© २०२५ शेतकरी साथी · कॉलेज मिनी-प्रोजेक्ट म्हणून तयार",
    hi: "© 2025 किसान साथी · कॉलेज मिनी-प्रोजेक्ट के रूप में बनाया गया",
  },

  notFoundTitle: { en: "Page not found", mr: "पान सापडले नाही", hi: "पृष्ठ नहीं मिला" },
  notFoundText: {
    en: "The page you're looking for doesn't exist.",
    mr: "तुम्ही शोधत असलेले पान अस्तित्वात नाही.",
    hi: "आप जो पृष्ठ खोज रहे हैं वह मौजूद नहीं है।",
  },
  goHome: { en: "Go home", mr: "मुख्यपृष्ठावर जा", hi: "मुख्य पृष्ठ पर जाएँ" },
};

function getLang() {
  const saved = window.localStorage.getItem("ss_lang");
  return saved === "en" || saved === "mr" || saved === "hi" ? saved : "en";
}

function t(key) {
  const lang = getLang();
  return (TRANSLATIONS[key] && TRANSLATIONS[key][lang]) || key;
}

function applyLang(lang) {
  window.localStorage.setItem("ss_lang", lang);
  document.documentElement.setAttribute("lang", lang);

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (TRANSLATIONS[key]) el.textContent = TRANSLATIONS[key][lang];
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (TRANSLATIONS[key]) el.setAttribute("placeholder", TRANSLATIONS[key][lang]);
  });

  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.getAttribute("data-lang") === lang);
  });

  // Let the current page re-render anything that depends on data (schemes/tools lists)
  if (typeof window.onLangChange === "function") window.onLangChange(lang);
}

function initLangButtons() {
  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => applyLang(btn.getAttribute("data-lang")));
  });
}

function highlightActiveNavLink() {
  const path = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-link").forEach((link) => {
    const href = link.getAttribute("href");
    if (href === path || (path === "" && href === "index.html")) {
      link.classList.add("active");
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initLangButtons();
  highlightActiveNavLink();
  applyLang(getLang());
});
