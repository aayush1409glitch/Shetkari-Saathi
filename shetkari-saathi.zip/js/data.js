// All the scheme and tool data for the site.
// Each text field is an object with en / mr / hi versions.

const SCHEMES = [
  {
    id: "pm-kisan",
    name: {
      en: "PM-KISAN Samman Nidhi",
      mr: "पीएम-किसान सन्मान निधी",
      hi: "पीएम-किसान सम्मान निधि",
    },
    summary: {
      en: "Direct income support of Rs 6,000 per year to eligible farmer families, paid in three equal installments.",
      mr: "पात्र शेतकरी कुटुंबांना दरवर्षी ६,००० रुपये थेट उत्पन्न मदत, तीन समान हप्त्यांत दिली जाते.",
      hi: "पात्र किसान परिवारों को हर साल 6,000 रुपये की सीधी आय सहायता, तीन समान किस्तों में दी जाती है।",
    },
    eligibility: {
      en: "Small and marginal farmer families with cultivable land, subject to exclusion criteria.",
      mr: "शेतीयोग्य जमीन असलेली लहान व अल्पभूधारक शेतकरी कुटुंबे, वगळणी निकषांनुसार.",
      hi: "खेती योग्य भूमि वाले छोटे और सीमांत किसान परिवार, बहिष्करण मानदंडों के अधीन।",
    },
    benefit: {
      en: "Rs 2,000 x 3 installments = Rs 6,000 per year, credited directly to Aadhaar-linked bank account.",
      mr: "२,००० x ३ हप्ते = वर्षाला ६,००० रुपये, आधार जोडलेल्या बँक खात्यात थेट जमा.",
      hi: "2,000 x 3 किस्तें = साल में 6,000 रुपये, आधार से जुड़े बैंक खाते में सीधे जमा।",
    },
    apply: {
      en: "Register on the PM-KISAN portal or through the nearest Common Service Centre (CSC) with Aadhaar and land records.",
      mr: "आधार आणि सातबारा सोबत घेऊन पीएम-किसान पोर्टलवर किंवा जवळच्या CSC केंद्रावर नोंदणी करा.",
      hi: "आधार और भूमि रिकॉर्ड लेकर पीएम-किसान पोर्टल पर या नज़दीकी CSC केंद्र पर पंजीकरण करें।",
    },
    link: "https://pmkisan.gov.in",
    tag: { en: "Central", mr: "केंद्र", hi: "केंद्र" },
  },
  {
    id: "pmfby",
    name: {
      en: "Pradhan Mantri Fasal Bima Yojana",
      mr: "प्रधानमंत्री पीक विमा योजना",
      hi: "प्रधानमंत्री फसल बीमा योजना",
    },
    summary: {
      en: "Crop insurance scheme covering yield losses from natural calamities, pests and diseases.",
      mr: "नैसर्गिक आपत्ती, कीड व रोगामुळे होणाऱ्या उत्पादन नुकसानीसाठी पीक विमा योजना.",
      hi: "प्राकृतिक आपदाओं, कीटों और रोगों से होने वाले फसल नुकसान को कवर करने वाली फसल बीमा योजना।",
    },
    eligibility: {
      en: "All farmers growing notified crops in notified areas, including sharecroppers and tenant farmers.",
      mr: "अधिसूचित क्षेत्रात अधिसूचित पिके घेणारे सर्व शेतकरी, बटईदार व कुळ शेतकऱ्यांसह.",
      hi: "अधिसूचित क्षेत्रों में अधिसूचित फसलें उगाने वाले सभी किसान, बटाईदार व काश्तकार सहित।",
    },
    benefit: {
      en: "Low premium (2% Kharif, 1.5% Rabi, 5% commercial). Balance premium paid by government.",
      mr: "कमी हप्ता (खरीप २%, रब्बी १.५%, नगदी ५%). उर्वरित हप्ता शासन भरते.",
      hi: "कम प्रीमियम (खरीफ 2%, रबी 1.5%, वाणिज्यिक 5%)। बाकी प्रीमियम सरकार भरती है।",
    },
    apply: {
      en: "Apply through bank where crop loan is taken, CSC, insurance company agent, or the National Crop Insurance Portal.",
      mr: "पीक कर्ज घेतलेल्या बँकेत, CSC मध्ये, विमा कंपनी एजंटकडे किंवा राष्ट्रीय पीक विमा पोर्टलवर अर्ज करा.",
      hi: "फसल ऋण वाली बैंक शाखा, CSC, बीमा कंपनी एजेंट या राष्ट्रीय फसल बीमा पोर्टल पर आवेदन करें।",
    },
    link: "https://pmfby.gov.in",
    tag: { en: "Central", mr: "केंद्र", hi: "केंद्र" },
  },
  {
    id: "kcc",
    name: {
      en: "Kisan Credit Card (KCC)",
      mr: "किसान क्रेडिट कार्ड",
      hi: "किसान क्रेडिट कार्ड",
    },
    summary: {
      en: "Short-term credit for cultivation, post-harvest expenses and allied activities at subsidised interest.",
      mr: "अनुदानित व्याजदरात लागवड, कापणीनंतरचा खर्च व संलग्न कामांसाठी अल्पमुदती कर्ज.",
      hi: "अनुदानित ब्याज दर पर खेती, कटाई के बाद के खर्च और संबद्ध गतिविधियों के लिए अल्पकालिक ऋण।",
    },
    eligibility: {
      en: "All farmers - individual/joint, tenant farmers, oral lessees, SHGs and JLGs of farmers.",
      mr: "सर्व शेतकरी - वैयक्तिक/संयुक्त, कुळ शेतकरी, तोंडी भाडेकरू, शेतकरी SHG व JLG.",
      hi: "सभी किसान - व्यक्तिगत/संयुक्त, काश्तकार, मौखिक पट्टेदार, किसानों के SHG व JLG।",
    },
    benefit: {
      en: "Loans up to Rs 3 lakh at 7% interest, with 3% prompt repayment incentive (effective 4%).",
      mr: "३ लाखांपर्यंत कर्ज ७% व्याजदराने, वेळेवर परतफेडीवर ३% सूट (प्रभावी ४%).",
      hi: "3 लाख तक का ऋण 7% ब्याज पर, समय पर चुकौती पर 3% छूट (प्रभावी 4%)।",
    },
    apply: {
      en: "Apply at any nationalised bank, cooperative bank or RRB branch with land records and ID proof.",
      mr: "जमीन कागदपत्रे व ओळखपत्रासह कोणत्याही राष्ट्रीयीकृत, सहकारी बँक किंवा RRB शाखेत अर्ज करा.",
      hi: "भूमि दस्तावेज़ और पहचान प्रमाण के साथ किसी भी राष्ट्रीयकृत, सहकारी बैंक या RRB शाखा में आवेदन करें।",
    },
    link: "https://www.myscheme.gov.in/schemes/kcc",
    tag: { en: "Credit", mr: "कर्ज", hi: "ऋण" },
  },
  {
    id: "mahadbt",
    name: {
      en: "MahaDBT Farmer Schemes",
      mr: "महाडीबीटी शेतकरी योजना",
      hi: "महाडीबीटी किसान योजनाएँ",
    },
    summary: {
      en: "Single portal for Maharashtra state farmer subsidies - seeds, drip irrigation, farm machinery, horticulture.",
      mr: "महाराष्ट्र शासनाच्या शेतकरी अनुदानांसाठी एकच पोर्टल - बियाणे, ठिबक सिंचन, यंत्रे, फलोत्पादन.",
      hi: "महाराष्ट्र सरकार की किसान सब्सिडी के लिए एकल पोर्टल - बीज, ड्रिप सिंचाई, कृषि यंत्र, बागवानी।",
    },
    eligibility: {
      en: "Farmers residing in Maharashtra with 7/12 extract and Aadhaar-linked bank account.",
      mr: "महाराष्ट्रात राहणारे शेतकरी, ज्यांच्याकडे ७/१२ उतारा व आधार जोडलेले बँक खाते आहे.",
      hi: "महाराष्ट्र में रहने वाले किसान जिनके पास 7/12 उद्धरण और आधार से जुड़ा बैंक खाता है।",
    },
    benefit: {
      en: "Component-wise subsidy (usually 50%-90%) transferred directly to farmer's bank account via DBT.",
      mr: "घटकनिहाय अनुदान (साधारण ५०%-९०%) DBT द्वारे थेट शेतकऱ्याच्या बँक खात्यात.",
      hi: "घटक-वार सब्सिडी (आमतौर पर 50%-90%) DBT के माध्यम से सीधे किसान के बैंक खाते में।",
    },
    apply: {
      en: "Register on mahadbt.maharashtra.gov.in, upload documents and select the required schemes.",
      mr: "mahadbt.maharashtra.gov.in वर नोंदणी करा, कागदपत्रे अपलोड करा व आवश्यक योजना निवडा.",
      hi: "mahadbt.maharashtra.gov.in पर पंजीकरण करें, दस्तावेज़ अपलोड करें और आवश्यक योजनाएँ चुनें।",
    },
    link: "https://mahadbt.maharashtra.gov.in",
    tag: { en: "Maharashtra", mr: "महाराष्ट्र", hi: "महाराष्ट्र" },
  },
  {
    id: "namo-shetkari",
    name: {
      en: "Namo Shetkari Mahasanman Nidhi",
      mr: "नमो शेतकरी महासन्मान निधी",
      hi: "नमो शेतकरी महासम्मान निधि",
    },
    summary: {
      en: "Maharashtra top-up of Rs 6,000 per year to PM-KISAN beneficiaries in the state.",
      mr: "राज्यातील पीएम-किसान लाभार्थ्यांना महाराष्ट्र शासनाकडून अतिरिक्त वार्षिक ६,००० रुपये.",
      hi: "राज्य के पीएम-किसान लाभार्थियों को महाराष्ट्र सरकार से अतिरिक्त वार्षिक 6,000 रुपये।",
    },
    eligibility: {
      en: "PM-KISAN registered farmer families residing in Maharashtra.",
      mr: "महाराष्ट्रात राहणारी पीएम-किसान नोंदणीकृत शेतकरी कुटुंबे.",
      hi: "महाराष्ट्र में रहने वाले पीएम-किसान पंजीकृत किसान परिवार।",
    },
    benefit: {
      en: "Additional Rs 6,000 per year, making the combined income support Rs 12,000 annually.",
      mr: "अतिरिक्त वर्षाला ६,००० रुपये, एकूण उत्पन्न मदत १२,००० रुपये प्रति वर्ष.",
      hi: "अतिरिक्त 6,000 रुपये प्रति वर्ष, कुल आय सहायता 12,000 रुपये प्रति वर्ष।",
    },
    apply: {
      en: "Automatic for PM-KISAN beneficiaries in Maharashtra. Ensure eKYC and Aadhaar seeding is complete.",
      mr: "महाराष्ट्रातील पीएम-किसान लाभार्थ्यांसाठी स्वयंचलित. eKYC व आधार जोडणी पूर्ण असल्याची खात्री करा.",
      hi: "महाराष्ट्र के पीएम-किसान लाभार्थियों के लिए स्वचालित। eKYC और आधार लिंकिंग पूरी होनी चाहिए।",
    },
    link: "https://nsmny.mahait.org",
    tag: { en: "Maharashtra", mr: "महाराष्ट्र", hi: "महाराष्ट्र" },
  },
  {
    id: "pmegp",
    name: {
      en: "PMEGP - Rural Entrepreneurship",
      mr: "पीएमईजीपी - ग्रामीण उद्योजकता",
      hi: "पीएमईजीपी - ग्रामीण उद्यमिता",
    },
    summary: {
      en: "Credit-linked subsidy to set up new micro-enterprises in the non-farm sector, for first generation entrepreneurs.",
      mr: "बिगर-शेती क्षेत्रात नवीन सूक्ष्म उद्योग सुरू करण्यासाठी कर्ज-संलग्न अनुदान, नवउद्योजकांसाठी.",
      hi: "गैर-कृषि क्षेत्र में नए सूक्ष्म उद्यम शुरू करने के लिए ऋण-आधारित सब्सिडी, नए उद्यमियों के लिए।",
    },
    eligibility: {
      en: "Individuals above 18 years, at least 8th pass for projects above Rs 10 lakh (manufacturing) / Rs 5 lakh (service).",
      mr: "१८ वर्षांवरील व्यक्ती, १० लाखांवरील (उत्पादन) / ५ लाखांवरील (सेवा) प्रकल्पासाठी किमान ८वी उत्तीर्ण.",
      hi: "18 वर्ष से ऊपर के व्यक्ति, 10 लाख (विनिर्माण) / 5 लाख (सेवा) से ऊपर के प्रोजेक्ट के लिए न्यूनतम 8वीं पास।",
    },
    benefit: {
      en: "Subsidy of 25%-35% of project cost in rural areas (higher for special categories). Up to Rs 50 lakh manufacturing, Rs 20 lakh service.",
      mr: "ग्रामीण भागात प्रकल्प खर्चाच्या २५%-३५% अनुदान (विशेष प्रवर्गासाठी अधिक). उत्पादन ५० लाख, सेवा २० लाखांपर्यंत.",
      hi: "ग्रामीण क्षेत्रों में परियोजना लागत का 25%-35% अनुदान (विशेष श्रेणियों के लिए अधिक)। विनिर्माण 50 लाख, सेवा 20 लाख तक।",
    },
    apply: {
      en: "Apply online at kviconline.gov.in/pmegpeportal. Attend EDP training after in-principle approval.",
      mr: "kviconline.gov.in/pmegpeportal वर ऑनलाइन अर्ज करा. तत्वतः मंजुरीनंतर EDP प्रशिक्षण घ्या.",
      hi: "kviconline.gov.in/pmegpeportal पर ऑनलाइन आवेदन करें। सैद्धांतिक मंजूरी के बाद EDP प्रशिक्षण लें।",
    },
    link: "https://www.kviconline.gov.in/pmegpeportal",
    tag: { en: "Entrepreneurship", mr: "उद्योजकता", hi: "उद्यमिता" },
  },
  {
    id: "soil-health",
    name: {
      en: "Soil Health Card Scheme",
      mr: "मृदा आरोग्य पत्रिका योजना",
      hi: "मृदा स्वास्थ्य कार्ड योजना",
    },
    summary: {
      en: "Free soil testing and nutrient recommendations issued as a Soil Health Card every 2 years.",
      mr: "दर २ वर्षांनी मोफत माती तपासणी व पोषकद्रव्य शिफारशी असलेले मृदा आरोग्य पत्रिका.",
      hi: "हर 2 वर्ष में मुफ्त मिट्टी परीक्षण और पोषक तत्व सिफारिशों के साथ मृदा स्वास्थ्य कार्ड।",
    },
    eligibility: {
      en: "All landholding farmers in India.",
      mr: "भारतातील सर्व जमीनधारक शेतकरी.",
      hi: "भारत के सभी भूमिधारक किसान।",
    },
    benefit: {
      en: "Reduces fertiliser cost by giving crop-specific and soil-specific recommendations.",
      mr: "पीक व मातीनुसार शिफारशी देऊन खतांचा खर्च कमी करते.",
      hi: "फसल और मिट्टी-विशिष्ट सिफारिशें देकर उर्वरक लागत कम करता है।",
    },
    apply: {
      en: "Contact the local Krishi Vigyan Kendra, Agriculture Assistant or apply on soilhealth.dac.gov.in.",
      mr: "स्थानिक कृषी विज्ञान केंद्र, कृषी सहाय्यकाशी संपर्क साधा किंवा soilhealth.dac.gov.in वर अर्ज करा.",
      hi: "स्थानीय कृषि विज्ञान केंद्र, कृषि सहायक से संपर्क करें या soilhealth.dac.gov.in पर आवेदन करें।",
    },
    link: "https://soilhealth.dac.gov.in",
    tag: { en: "Central", mr: "केंद्र", hi: "केंद्र" },
  },
  {
    id: "mudra",
    name: {
      en: "PM MUDRA Yojana",
      mr: "पीएम मुद्रा योजना",
      hi: "पीएम मुद्रा योजना",
    },
    summary: {
      en: "Collateral-free loans up to Rs 10 lakh for non-farm micro and small businesses.",
      mr: "बिगर-शेती सूक्ष्म व लघु उद्योगांसाठी १० लाखांपर्यंत तारणमुक्त कर्ज.",
      hi: "गैर-कृषि सूक्ष्म व लघु व्यवसायों के लिए 10 लाख तक का बिना गारंटी ऋण।",
    },
    eligibility: {
      en: "Any Indian citizen with a viable business plan in trading, manufacturing, service or allied agriculture.",
      mr: "व्यापार, उत्पादन, सेवा किंवा संलग्न शेती क्षेत्रात व्यवसाय योजना असलेला कोणताही भारतीय नागरिक.",
      hi: "व्यापार, विनिर्माण, सेवा या संबद्ध कृषि में व्यवहार्य व्यवसाय योजना वाला कोई भी भारतीय नागरिक।",
    },
    benefit: {
      en: "Shishu (up to 50k), Kishor (50k-5L), Tarun (5L-10L). No collateral, low interest.",
      mr: "शिशु (५०,००० पर्यंत), किशोर (५०,०००-५ लाख), तरुण (५-१० लाख). तारण नाही, कमी व्याज.",
      hi: "शिशु (50 हजार तक), किशोर (50 हजार-5 लाख), तरुण (5-10 लाख)। कोई गारंटी नहीं, कम ब्याज।",
    },
    apply: {
      en: "Approach any bank branch, NBFC or MFI. Online applications via udyamimitra.in.",
      mr: "कोणत्याही बँक शाखेत, NBFC किंवा MFI कडे जा. udyamimitra.in वर ऑनलाइन अर्ज.",
      hi: "किसी भी बैंक शाखा, NBFC या MFI में जाएँ। udyamimitra.in पर ऑनलाइन आवेदन।",
    },
    link: "https://www.mudra.org.in",
    tag: { en: "Entrepreneurship", mr: "उद्योजकता", hi: "उद्यमिता" },
  },
];

const TOOLS = [
  {
    id: "kisan-suvidha",
    name: "Kisan Suvidha",
    description: {
      en: "Official Government of India app giving weather, market prices, plant protection and expert advice in local languages.",
      mr: "स्थानिक भाषेत हवामान, बाजारभाव, पीक संरक्षण व तज्ज्ञ सल्ला देणारे भारत सरकारचे अधिकृत ॲप.",
      hi: "स्थानीय भाषाओं में मौसम, बाजार भाव, फसल सुरक्षा और विशेषज्ञ सलाह देने वाला भारत सरकार का आधिकारिक ऐप।",
    },
    link: "https://play.google.com/store/apps/details?id=in.gov.kisan",
    category: { en: "Advisory", mr: "सल्ला", hi: "सलाह" },
  },
  {
    id: "agmarknet",
    name: "AgMarknet",
    description: {
      en: "Daily wholesale mandi prices for hundreds of crops across India. Compare rates before selling.",
      mr: "भारतभरातील शेकडो पिकांचे दैनिक बाजार समिती दर. विक्रीपूर्वी दर तपासा.",
      hi: "भारत भर में सैकड़ों फसलों के दैनिक थोक मंडी भाव। बेचने से पहले दर तुलना करें।",
    },
    link: "https://agmarknet.gov.in",
    category: { en: "Market", mr: "बाजार", hi: "बाजार" },
  },
  {
    id: "enam",
    name: "e-NAM",
    description: {
      en: "National electronic agricultural market. Sell produce online to a wider buyer base with transparent price discovery.",
      mr: "राष्ट्रीय कृषी इलेक्ट्रॉनिक बाजार. पारदर्शक दराने अधिक खरेदीदारांना ऑनलाइन शेतमाल विका.",
      hi: "राष्ट्रीय कृषि इलेक्ट्रॉनिक बाजार। पारदर्शी मूल्य के साथ अधिक खरीदारों को ऑनलाइन उपज बेचें।",
    },
    link: "https://enam.gov.in",
    category: { en: "Market", mr: "बाजार", hi: "बाजार" },
  },
  {
    id: "mkisan",
    name: "mKisan Portal",
    description: {
      en: "SMS-based advisories in local language from KVKs, agriculture universities and experts.",
      mr: "KVK, कृषी विद्यापीठे व तज्ज्ञांकडून स्थानिक भाषेत SMS द्वारे सल्ला.",
      hi: "KVK, कृषि विश्वविद्यालयों और विशेषज्ञों से स्थानीय भाषा में SMS सलाह।",
    },
    link: "https://mkisan.gov.in",
    category: { en: "Advisory", mr: "सल्ला", hi: "सलाह" },
  },
  {
    id: "upi",
    name: "UPI / BHIM",
    description: {
      en: "Send and receive payments instantly using just a mobile number or QR. Zero transaction fees for most farmers and small shops.",
      mr: "फक्त मोबाइल नंबर किंवा QR वापरून त्वरित पैसे पाठवा व स्वीकारा. बहुतांश शेतकरी व लहान दुकानांसाठी शून्य शुल्क.",
      hi: "बस मोबाइल नंबर या QR से तुरंत पैसे भेजें व प्राप्त करें। ज़्यादातर किसानों व छोटी दुकानों के लिए शून्य शुल्क।",
    },
    link: "https://www.bhimupi.org.in",
    category: { en: "Payments", mr: "पेमेंट", hi: "भुगतान" },
  },
  {
    id: "digilocker",
    name: "DigiLocker",
    description: {
      en: "Store Aadhaar, 7/12 extract, driving licence and other documents digitally. Accepted by all government offices.",
      mr: "आधार, ७/१२, वाहन परवाना व इतर कागदपत्रे डिजिटल स्वरूपात ठेवा. सर्व शासकीय कार्यालयांत मान्य.",
      hi: "आधार, 7/12, ड्राइविंग लाइसेंस व अन्य दस्तावेज़ डिजिटल रूप से रखें। सभी सरकारी कार्यालयों में मान्य।",
    },
    link: "https://digilocker.gov.in",
    category: { en: "Documents", mr: "कागदपत्रे", hi: "दस्तावेज़" },
  },
  {
    id: "umang",
    name: "UMANG",
    description: {
      en: "Single app for 1500+ government services including EPFO, PAN, gas booking, farmer schemes.",
      mr: "EPFO, PAN, गॅस बुकिंग, शेतकरी योजना यांसह १५००+ शासकीय सेवांसाठी एकच ॲप.",
      hi: "EPFO, PAN, गैस बुकिंग, किसान योजनाओं सहित 1500+ सरकारी सेवाओं के लिए एकल ऐप।",
    },
    link: "https://web.umang.gov.in",
    category: { en: "Services", mr: "सेवा", hi: "सेवाएँ" },
  },
  {
    id: "meri-pehchaan",
    name: "MeriPehchaan",
    description: {
      en: "One login for all National Single Sign-On enabled government portals. Reduces password fatigue.",
      mr: "राष्ट्रीय एकल साइन-ऑन सक्षम शासकीय पोर्टलसाठी एकच लॉगिन. पासवर्डचा त्रास कमी.",
      hi: "राष्ट्रीय एकल साइन-ऑन सक्षम सरकारी पोर्टलों के लिए एकल लॉगिन। पासवर्ड की थकान कम।",
    },
    link: "https://meripehchaan.gov.in",
    category: { en: "Services", mr: "सेवा", hi: "सेवाएँ" },
  },
];
